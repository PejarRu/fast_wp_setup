<?php
/**
 * Plugin Name: Auto-Config (ASE & Elementor)
 * Description: Una sola página con dos secciones: Auto-Config ASE (5 perfiles) y Auto-Config Elementor (un perfil global). Envía peticiones POST a wp-admin/options.php con nonce y cookies automáticos.
 * Version: 1.0
 * Author: Tu Nombre
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evitar acceso directo
}

/**
 * 1) Creación de un menú padre único
 */
add_action( 'admin_menu', 'acpe_add_menu' );
function acpe_add_menu() {
    add_menu_page(
        'Auto-Config (ASE & Elementor)',          // Título de la página
        'Auto-Config (ASE & Elementor)',          // Texto del menú
        'manage_options',                         // Capacidad
        'auto-config-ase-elementor',              // slug
        'acpe_admin_page',                        // callback de contenido
        'dashicons-admin-generic',
        80
    );
}

/**
 * 2) Página única con dos secciones:
 *    - Auto-Config ASE
 *    - Auto-Config Elementor
 */
function acpe_admin_page() {
    // Variables estáticas para guardar la depuración de cada formulario
    static $ase_args         = null;
    static $ase_response     = null;
    static $elementor_args   = null;
    static $elementor_response = null;

    // 2.1) Si se envía el formulario de ASE (5 perfiles)
    if ( isset( $_POST['aca_send_request'] ) ) {
        // Tomamos el perfil
        $selected_profile = isset( $_POST['aca_profile'] ) ? sanitize_text_field( $_POST['aca_profile'] ) : '';
        // Llamamos a la función que hace la petición
        list( $ase_args, $ase_response ) = acpe_send_custom_request_ase( $selected_profile );
    }

    // 2.2) Si se envía el formulario de Elementor (un perfil global)
    if ( isset( $_POST['ace_send_elementor_request'] ) ) {
        list( $elementor_args, $elementor_response ) = acpe_send_custom_request_elementor();
    }
    ?>
    <div class="wrap">
        <h1 style="margin-bottom:1em;">Auto-Config (ASE &amp; Elementor)</h1>

        <!-- ======================
             SECCIÓN 1: AUTO-CONFIG ASE
             ====================== -->
        <div style="background:#f9f9f9; border:1px solid #ccc; padding:20px; max-width:800px; border-radius:6px;">
            <h2 style="margin-top:0;">Auto-Config ASE</h2>
            <p style="margin:0.5em 0 1em;">
                Selecciona uno de los 5 perfiles (Sánchez, Antón, Parra, Miguel, Christian)
                para enviar una configuración distinta al plugin <strong>Admin Site Enhancements</strong>.
            </p>

            <form method="post" style="display:flex; align-items:center; gap:1em; flex-wrap:wrap;">
                <?php wp_nonce_field( 'aca_send_request_nonce', 'aca_nonce_field' ); ?>

                <label for="aca_profile" style="font-weight:bold;">Seleccionar perfil:</label>
                <select name="aca_profile" id="aca_profile" style="min-width:200px;">
                    <option value="">-- Seleccionar --</option>
                    <option value="sanchez">Sánchez</option>
                    <option value="anton">Antón</option>
                    <option value="parra">Parra</option>
                    <option value="miguel">Miguel</option>
                    <option value="christian">Christian</option>
                </select>

                <input type="submit"
                       name="aca_send_request"
                       value="Enviar Petición ASE"
                       style="background:#0073aa; color:#fff; border:none; padding:8px 16px; border-radius:4px; cursor:pointer;"
                       onclick="return confirm('¿Estás seguro de enviar la petición (ASE) con el perfil seleccionado?');"/>
            </form>
        </div>
        <?php
        // Depuración ASE si existe respuesta
        if ( $ase_response !== null ) {
            acpe_show_debug_info( $ase_args, $ase_response, 'ASE' );
        }
        ?>

        <br><br>

        <!-- ======================
             SECCIÓN 2: AUTO-CONFIG ELEMENTOR
             ====================== -->
        <div style="background:#f9f9f9; border:1px solid #ccc; padding:20px; max-width:800px; border-radius:6px;">
            <h2 style="margin-top:0;">Auto-Config Elementor</h2>
            <p style="margin:0.5em 0 1em;">
                Al pulsar el botón, se aplicará una configuración “global” en <strong>Elementor</strong> 
                (option_page=elementor), capturando dinámicamente el nonce y cookies.
            </p>

            <form method="post">
                <?php wp_nonce_field( 'ace_send_elementor_nonce', 'ace_nonce_field' ); ?>
                <input type="submit"
                       name="ace_send_elementor_request"
                       value="Aplicar Configuración Elementor"
                       style="background:#0073aa; color:#fff; border:none; padding:8px 16px; border-radius:4px; cursor:pointer;"
                       onclick="return confirm('¿Estás seguro de enviar la configuración a Elementor?');"/>
            </form>
        </div>
        <?php
        // Depuración Elementor si existe respuesta
        if ( $elementor_response !== null ) {
            acpe_show_debug_info( $elementor_args, $elementor_response, 'Elementor' );
        }
        ?>
    </div>
    <?php
}

/* ============================================================================
   3) PETICIÓN ASE (perfiles)
   ============================================================================ */
function acpe_send_custom_request_ase( $profile ) {
    check_admin_referer( 'aca_send_request_nonce', 'aca_nonce_field' );

    $body = acpe_get_profile_config_ase( $profile );

    if ( empty( $body ) ) {
        echo '<div class="notice notice-error"><p>No se encontró configuración para el perfil seleccionado.</p></div>';
        return array( array(), array() );
    }

    // Capturar nonce & referer para "asenha"
    $captured = acpe_extract_nonce_and_referer( 'asenha' );
    $body['_wpnonce']         = $captured['nonce'];
    $body['_wp_http_referer'] = $captured['referer'];

    $cookies = acpe_build_cookies_array();
    $url = admin_url( 'options.php' );

    $args = array(
        'method'  => 'POST',
        'headers' => array(
            'User-Agent'   => 'Mozilla/5.0 (Plugin ASE)',
            'Accept'       => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Content-Type' => 'application/x-www-form-urlencoded',
        ),
        'cookies' => $cookies,
        'body'    => $body,
        'timeout' => 30,
        'sslverify' => false
    );

    $response = wp_remote_post( $url, $args );

    if ( is_wp_error( $response ) ) {
        echo '<div class="notice notice-error"><p><strong>Error al enviar la petición ASE:</strong> ' . esc_html( $response->get_error_message() ) . '</p></div>';
    } else {
        $code = wp_remote_retrieve_response_code( $response );
        echo '<div class="notice notice-success"><p>Petición ASE enviada. Perfil: <strong>' . esc_html( ucfirst( $profile ) ) . '</strong>. Código HTTP: ' . esc_html( $code ) . '</p></div>';
    }

    return array( $args, $response );
}

/**
 * Config (body) para los 5 perfiles ASE
 */
function acpe_get_profile_config_ase( $profile ) {
    $profiles = array(
        'sanchez' => array(
            'tabs' => 'on',
            'admin_site_enhancements' => array(
                'enable_duplication' => 'on',
                'duplication_redirect_destination' => 'edit',
                'content_order' => 'on',
                'enable_media_replacement' => 'on',
                'enable_svg_upload' => 'on',
                'enable_avif_upload' => 'on',
                'enable_external_permalinks' => 'on',
                'external_links_new_tab' => 'on',
                'custom_nav_menu_items_new_tab' => 'on',
                'enable_missed_schedule_posts_auto_publish' => 'on',
                'disable_dashboard_widgets' => 'on',
                'disable_welcome_panel_in_dashboard' => 'on',
                'disabled_dashboard_widgets' => array(
                    'dashboard_activity__normal__core'  => 'on',
                    'dashboard_quick_press__side__core' => 'on',
                    'e-dashboard-overview__normal__core'=> 'on',
                    'dashboard_right_now__normal__core' => 'on',
                    'dashboard_site_health__normal__core'=> 'on',
                    'dashboard_primary__side__core'     => 'on',
                ),
                'admin_menu_width' => '180px',
                'custom_menu_order' => 'menu-dashboard,separator1,menu-posts,menu-posts-mi_blog,menu-media,menu-pages,menu-comments,separator-elementor,toplevel_page_elementor,menu-posts-elementor_library,separator2,menu-appearance,menu-plugins,menu-users,menu-tools,menu-settings,toplevel_page_savour-meta-debugger,separator-last,toplevel_page_configurador-sitio,toplevel_page_wp_file_manager',
                'custom_menu_titles' => 'menu-posts__Entradas,menu-posts-mi_blog__Blog Personal,toplevel_page_elementor__Elementor,menu-posts-elementor_library__Plantillas,toplevel_page_savour-meta-debugger__Meta Debugger,toplevel_page_configurador-sitio__Savour Manager v.1,toplevel_page_wp_file_manager__Administrador de archivos WP',
                'custom_menu_hidden' => '',
                'custom_admin_footer_left' => '',
                'custom_admin_footer_right' => '',
                'custom_login_slug' => '',
                'login_id_type' => 'username',
                'site_identity_on_login' => 'on',
                'redirect_after_login_to_slug' => '',
                'redirect_after_logout_to_slug' => '',
                'custom_admin_css' => '',
                'custom_frontend_css' => '',
                'head_code_priority' => '',
                'head_code' => '',
                'body_code_priority' => '',
                'body_code' => '',
                'footer_code_priority' => '',
                'footer_code' => '',
                'ads_txt_content' => '',
                'app_ads_txt_content' => '',
                'robots_txt_content' => "User-agent: *\r\nDisallow: /wp-admin/\r\nAllow: /wp-admin/admin-ajax.php\r\n\r\nSitemap: https://chiringuitosangil.com/wp-sitemap.xml",
                'disable_gutenberg' => 'on',
                'disable_gutenberg_for' => array(
                    'post' => 'on',
                    'page' => 'on',
                    'wp_font_family' => 'on',
                    'wp_font_face' => 'on',
                    'e-landing-page' => 'on',
                    'e-floating-buttons' => 'on',
                    'elementor_library' => 'on',
                    'elementor_snippet' => 'on',
                    'mi_blog' => 'on',
                    'language_switcher' => 'on',
                    'elementor_font' => 'on',
                    'elementor_icons' => 'on',
                ),
                'disable_gutenberg_frontend_styles' => 'on',
                'disable_comments' => 'on',
                'disable_comments_for' => array(
                    'mi_blog' => 'on',
                    'e-floating-buttons' => 'on',
                    'post' => 'on',
                    'attachment' => 'on',
                    'elementor_library' => 'on',
                    'page' => 'on',
                    'e-landing-page' => 'on',
                ),
                'disable_rest_api' => 'on',
                'disable_smaller_components' => 'on',
                'disable_head_generator_tag' => 'on',
                'disable_feed_generator_tag' => 'on',
                'disable_resource_version_number' => 'on',
                'disable_head_wlwmanifest_tag' => 'on',
                'disable_head_rsd_tag' => 'on',
                'disable_head_shortlink_tag' => 'on',
                'disable_frontend_dashicons' => 'on',
                'disable_emoji_support' => 'on',
                'disable_jquery_migrate' => 'on',
                'disable_block_widgets' => 'on',
                'disable_lazy_load' => 'on',
                'limit_login_attempts' => 'on',
                'login_fails_allowed' => '',
                'login_lockout_maxcount' => '',
                'login_attempts_log_table' => '',
                'obfuscate_author_slugs' => 'on',
                'disable_xmlrpc' => 'on',
                'image_max_width' => '',
                'image_max_height' => '',
                'revisions_max_number' => '',
                'heartbeat_control_for_admin_pages' => 'default',
                'heartbeat_interval_for_admin_pages' => '60',
                'heartbeat_control_for_post_edit' => 'default',
                'heartbeat_interval_for_post_edit' => '15',
                'heartbeat_control_for_frontend' => 'default',
                'heartbeat_interval_for_frontend' => '60',
                'smtp_default_from_name' => '',
                'smtp_default_from_email' => '',
                'smtp_host' => '',
                'smtp_port' => '',
                'smtp_username' => '',
                'smtp_password' => '',
                'password_protection_password' => '',
                'maintenance_page_heading' => '',
                'maintenance_page_description' => '',
            ),
            'option_page' => 'asenha',
            'action'      => 'update',
            'submit'      => 'Guardar cambios',
            'login-attempts-log_length' => 10,
        ),
        'anton' => array(
            'tabs' => 'on',
            'admin_site_enhancements' => array(
                'enable_duplication' => 'on',
                'duplication_redirect_destination' => 'edit',
                'content_order' => 'on',
                'enable_media_replacement' => 'on',
                'enable_svg_upload' => 'on',
                'enable_avif_upload' => 'on',
                'enable_external_permalinks' => 'on',
                'external_links_new_tab' => 'on',
                'custom_nav_menu_items_new_tab' => 'on',
                'enable_missed_schedule_posts_auto_publish' => 'on',
                'disable_welcome_panel_in_dashboard' => 'on',
                'disabled_dashboard_widgets' => array(
                    'dashboard_activity__normal__core'  => 'on',
                    'dashboard_quick_press__side__core'   => 'on',
                    'e-dashboard-overview__normal__core'  => 'on',
                    'dashboard_right_now__normal__core'   => 'on',
                    'dashboard_site_health__normal__core' => 'on',
                    'dashboard_primary__side__core'       => 'on',
                ),
                'admin_menu_width' => '180px',
                'custom_menu_order' => 'menu-dashboard,separator1,menu-posts,menu-posts-mi_blog,menu-media,menu-pages,menu-comments,separator-elementor,toplevel_page_elementor,menu-posts-elementor_library,separator2,menu-appearance,menu-plugins,menu-users,menu-tools,menu-settings,separator-last,toplevel_page_configurador-sitio,toplevel_page_wp_file_manager,toplevel_page_auto-config-ase-elementor',
                'custom_menu_titles' => 'menu-posts__Entradas,menu-posts-mi_blog__Blog Personal,toplevel_page_elementor__Elementor,menu-posts-elementor_library__Plantillas,toplevel_page_configurador-sitio__Savour Manager v.1,toplevel_page_wp_file_manager__Administrador de archivos WP,toplevel_page_auto-config-ase-elementor__Auto-Config (ASE & Elementor)',
                'custom_menu_hidden' => '',
                'custom_admin_footer_left' => '',
                'custom_admin_footer_right' => '',
                'custom_login_slug' => 'backend',
                'login_id_type' => 'username',
                'redirect_after_login_to_slug' => '',
                'redirect_after_logout_to_slug' => '',
                'custom_admin_css' => '',
                'custom_frontend_css' => '',
                'head_code_priority' => '10',
                'head_code' => '',
                'body_code_priority' => '10',
                'body_code' => '',
                'footer_code_priority' => '10',
                'footer_code' => '',
                'ads_txt_content' => '',
                'app_ads_txt_content' => '',
                'robots_txt_content' => "User-agent: *\r\nDisallow: /wp-admin/\r\nAllow: /wp-admin/admin-ajax.php\r\n\r\nSitemap: https://chiringuitosangil.com/wp-sitemap.xml",
                'disable_gutenberg' => 'on',
                'disable_gutenberg_for' => array(
                    'post' => 'on',
                    'page' => 'on',
                    'wp_font_family' => 'on',
                    'wp_font_face' => 'on',
                    'elementor_library' => 'on',
                    'elementor_snippet' => 'on',
                    'mi_blog' => 'on',
                    'language_switcher' => 'on',
                    'elementor_font' => 'on',
                    'elementor_icons' => 'on',
                ),
                'disable_gutenberg_frontend_styles' => 'on',
                'disable_comments' => 'on',
                'disable_comments_for' => array(
                    'mi_blog' => 'on',
                    'post' => 'on',
                    'attachment' => 'on',
                    'elementor_library' => 'on',
                    'page' => 'on',
                ),
                'disable_rest_api' => 'on',
                'disable_feeds' => 'on',
                'disable_all_updates' => 'on',
                'disable_smaller_components' => 'on',
                'disable_head_generator_tag' => 'on',
                'disable_feed_generator_tag' => 'on',
                'disable_resource_version_number' => 'on',
                'disable_head_wlwmanifest_tag' => 'on',
                'disable_head_rsd_tag' => 'on',
                'disable_head_shortlink_tag' => 'on',
                'disable_frontend_dashicons' => 'on',
                'disable_emoji_support' => 'on',
                'disable_jquery_migrate' => 'on',
                'disable_block_widgets' => 'on',
                'disable_lazy_load' => 'on',
                'limit_login_attempts' => 'on',
                'login_fails_allowed' => '3',
                'login_lockout_maxcount' => '3',
                'login-attempts_log_length' => 10,
                'login_attempts_log_table' => '',
                'obfuscate_author_slugs' => 'on',
                'obfuscate_email_address' => 'on',
                'disable_xmlrpc' => 'on',
                'image_upload_control' => 'on',
                'image_max_width' => '1920',
                'image_max_height' => '1920',
                'enable_revisions_control' => 'on',
                'revisions_max_number' => '10',
                'enable_heartbeat_control' => 'on',
                'heartbeat_control_for_admin_pages' => 'default',
                'heartbeat_interval_for_admin_pages' => '60',
                'heartbeat_control_for_post_edit' => 'default',
                'heartbeat_interval_for_post_edit' => '15',
                'heartbeat_control_for_frontend' => 'default',
                'heartbeat_interval_for_frontend' => '60',
                'smtp_default_from_name' => '',
                'smtp_default_from_email' => '',
                'smtp_host' => '',
                'smtp_port' => '',
                'smtp_security' => 'none',
                'smtp_username' => '',
                'smtp_password' => '',
                'password_protection_password' => 'secret',
                'maintenance_page_heading' => "We'll be back soon.",
                'maintenance_page_description' => "This site is undergoing maintenance for an extended period today. Thanks for your patience.",
                'maintenance_page_background' => 'stripes',
                'redirect_404_to_homepage' => 'on',
            ),
            'option_page' => 'asenha',
            'action'      => 'update',
            'submit'      => 'Guardar cambios',
        ),
        'parra' => array(),
        'miguel' => array(),
        'christian' => array(),
    );

    return isset( $profiles[$profile] ) ? $profiles[$profile] : array();
}

/* ============================================================================
   4) PETICIÓN ELEMENTOR (un perfil global)
   ============================================================================ */
function acpe_send_custom_request_elementor() {
    check_admin_referer( 'ace_send_elementor_nonce', 'ace_nonce_field' );

    // Config "global" de Elementor
    $body = acpe_get_elementor_config_global();

    // Capturamos nonce & referer para "elementor"
    $captured = acpe_extract_nonce_and_referer( 'elementor' );
    $body['_wpnonce']         = $captured['nonce'];
    $body['_wp_http_referer'] = $captured['referer'];

    $cookies = acpe_build_cookies_array();
    $url = admin_url( 'options.php' );

    $args = array(
        'method'  => 'POST',
        'headers' => array(
            'User-Agent'   => 'Mozilla/5.0 (Plugin Elementor)',
            'Accept'       => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Content-Type' => 'application/x-www-form-urlencoded',
        ),
        'cookies' => $cookies,
        'body'    => $body,
        'timeout' => 30,
        'sslverify' => false
    );

    $response = wp_remote_post( $url, $args );

    if ( is_wp_error( $response ) ) {
        echo '<div class="notice notice-error"><p><strong>Error al enviar la petición Elementor:</strong> ' . esc_html( $response->get_error_message() ) . '</p></div>';
    } else {
        $code = wp_remote_retrieve_response_code( $response );
        echo '<div class="notice notice-success"><p>Petición de Elementor enviada. Código HTTP: ' . esc_html( $code ) . '</p></div>';
    }

    return array( $args, $response );
}

/**
 * Config "global" de Elementor (replica exacta de tu POST)
 */
function acpe_get_elementor_config_global() {
    return array(
        'option_page' => 'elementor',
        'action'      => 'update',
        // _wpnonce y _wp_http_referer se inyectan dinámicamente

        '_elementor_settings_update_time' => '1738346821',
        'elementor_cpt_support' => array('post','page'),
        'elementor_disable_typography_schemes' => 'yes',
        'elementor_google_maps_api_key' => '',
        'elementor_pro_recaptcha_site_key' => '',
        'elementor_pro_recaptcha_secret_key' => '',
        'elementor_pro_recaptcha_v3_site_key' => '',
        'elementor_pro_recaptcha_v3_secret_key' => '',
        'elementor_pro_recaptcha_v3_threshold' => '0.5',
        'elementor_pro_facebook_app_id' => '',
        'elementor_pro_mailchimp_api_key' => '',
        'elementor_pro_drip_api_token' => '',
        'elementor_pro_activecampaign_api_key' => '',
        'elementor_pro_activecampaign_api_url' => '',
        'elementor_pro_getresponse_api_key' => '',
        'elementor_pro_convertkit_api_key' => '',
        'elementor_pro_mailerlite_api_key' => '',
        'elementor_typekit-kit-id' => '',
        'elementor_font_awesome_pro_kit_id' => '',
        'elementor_pro_stripe_test_secret_key' => '',
        'elementor_pro_stripe_live_secret_key' => '',
        'elementor_editor_break_lines' => '',
        'elementor_unfiltered_files_upload' => '1',
        'elementor_google_font' => '1',
        'elementor_font_display' => 'auto',
        'elementor_load_fa4_shim' => '',
        'elementor_meta_generator_tag' => '',
        'elementor_css_print_method' => 'external',
        'elementor_optimized_image_loading' => '1',
        'elementor_optimized_gutenberg_loading' => '1',
        'elementor_lazy_load_background_images' => '1',
        'elementor_element_cache_ttl' => '24',
        'elementor_experiment-e_optimized_markup' => 'active',
        'elementor_experiment-e_local_google_fonts' => 'active',
        'elementor_experiment-landing-pages' => 'active',
        'elementor_experiment-e_element_cache' => 'active',
        'elementor_experiment-page-transitions' => 'active',
        'elementor_experiment-loop' => 'active',
        'elementor_experiment-e_font_icon_svg' => 'active',
        'elementor_experiment-additional_custom_breakpoints' => 'active',
        'elementor_experiment-container' => 'active',
        'elementor_experiment-theme_builder_v2' => 'active',
        'elementor_experiment-hello-theme-header-footer' => 'active',
        'elementor_experiment-nested-elements' => 'active',
        'elementor_experiment-editor_v2' => 'active',
        'elementor_experiment-notes' => 'active',
        'elementor_experiment-form-submissions' => 'active',
        'elementor_experiment-e_scroll_snap' => 'active',

        'submit' => 'Guardar cambios',
    );
}

/* ============================================================================
   5) FUNCIONES COMUNES: Captura Nonce, Cookies, Debug
   ============================================================================ */

/**
 * Captura _wpnonce y _wp_http_referer con settings_fields($option_group)
 */
function acpe_extract_nonce_and_referer( $option_group ) {
    ob_start();
    settings_fields( $option_group );
    $fields_html = ob_get_clean();

    $nonce   = '';
    $referer = '';

    if ( preg_match( '/name="_wpnonce"\s+value="([^"]+)"/', $fields_html, $m ) ) {
        $nonce = $m[1];
    }
    if ( preg_match( '/name="_wp_http_referer"\s+value="([^"]+)"/', $fields_html, $m ) ) {
        $referer = $m[1];
    }

    return array(
        'nonce'   => $nonce,
        'referer' => $referer
    );
}

/**
 * Reúne cookies del usuario logueado
 */
function acpe_build_cookies_array() {
    $site_url = site_url();

    $host   = parse_url( $site_url, PHP_URL_HOST );
    $scheme = parse_url( $site_url, PHP_URL_SCHEME );

    // Quitar "www." si existe
    $host = preg_replace( '/^www\./i', '', $host );

    $path   = '/';
    $secure = ( strtolower( $scheme ) === 'https' );

    $cookies = array();

    foreach ( $_COOKIE as $name => $value ) {
        $cookies[] = new WP_Http_Cookie( array(
            'name'     => $name,
            'value'    => $value,
            'domain'   => $host,
            'path'     => $path,
            'secure'   => $secure,
            'httponly' => false,
        ));
    }

    return $cookies;
}

/**
 * Muestra la ventana de depuración
 */
function acpe_show_debug_info( $args, $response, $label = '' ) {
    ?>
    <div style="margin:2em 0; padding:1em; background:#fff; border:1px solid #ccc;">
        <h2>Depuración de la Petición <?php echo ($label ? '('.esc_html($label).')' : ''); ?></h2>
        <details>
            <summary>Ver argumentos (Request)</summary>
            <div style="padding:0.5em;">
                <pre><?php echo esc_html( print_r( $args, true ) ); ?></pre>
            </div>
        </details>
        <details style="margin-top:1em;">
            <summary>Ver respuesta (Response)</summary>
            <div style="padding:0.5em;">
            <?php
            if ( is_wp_error( $response ) ) {
                echo '<h4>WP_Error</h4><pre>' . esc_html( $response->get_error_message() ) . '</pre>';
            } else {
                $status = wp_remote_retrieve_response_code( $response );
                $body   = wp_remote_retrieve_body( $response );
                echo '<h4>Código HTTP:</h4><p>' . esc_html( $status ) . '</p>';
                echo '<h4>Body de la respuesta:</h4><pre>' . esc_html( $body ) . '</pre>';
            }
            ?>
            </div>
        </details>
    </div>
    <?php
}
