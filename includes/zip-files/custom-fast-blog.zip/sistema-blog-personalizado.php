<?php
/*
Plugin Name: Mi Blog Personal
Plugin URI:  https://tusitio.com
Description: Blog personalizable: fuentes, colores, alineaciones, tamaños, extracto en las tarjetas, y plantilla personalizada para la vista detallada.
Version:     1.4
Author:      Tu Nombre
Author URI:  https://tusitio.com
License:     GPL2
Text Domain: mi-blog-personal
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evitar acceso directo
}

/**
 * 1. Registrar el Custom Post Type "mi_blog".
 */
function mbp_registrar_cpt_blog() {
    $labels = array(
        'name'               => __('Blog Personal', 'mi-blog-personal'),
        'singular_name'      => __('Entrada de Blog', 'mi-blog-personal'),
        'add_new'            => __('Añadir Nuevo', 'mi-blog-personal'),
        'add_new_item'       => __('Añadir Nueva Entrada', 'mi-blog-personal'),
        'edit_item'          => __('Editar Entrada', 'mi-blog-personal'),
        'new_item'           => __('Nueva Entrada', 'mi-blog-personal'),
        'view_item'          => __('Ver Entrada', 'mi-blog-personal'),
        'search_items'       => __('Buscar Entradas', 'mi-blog-personal'),
        'not_found'          => __('No se encontraron entradas', 'mi-blog-personal'),
        'not_found_in_trash' => __('No se encontraron entradas en la papelera', 'mi-blog-personal'),
        'all_items'          => __('Todas las Entradas', 'mi-blog-personal'),
        'menu_name'          => __('Blog Personal', 'mi-blog-personal')
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'rewrite'            => array('slug' => 'blog-personal'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array('title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-format-aside',
    );

    register_post_type('mi_blog', $args);
}
add_action('init', 'mbp_registrar_cpt_blog');

/**
 * 2. Crear la página de Ajustes en "Ajustes -> Mi Blog Personal".
 */
function mbp_crear_menu_ajustes() {
    add_options_page(
        __('Ajustes - Mi Blog Personal', 'mi-blog-personal'),
        __('Mi Blog Personal', 'mi-blog-personal'),
        'manage_options',
        'mi-blog-personal-ajustes',
        'mbp_pagina_ajustes'
    );
}
add_action('admin_menu', 'mbp_crear_menu_ajustes');

/**
 * 3. Registrar los ajustes (opciones).
 */
function mbp_registrar_ajustes() {
    register_setting('mbp_ajustes_grupo', 'mbp_settings');
}
add_action('admin_init', 'mbp_registrar_ajustes');

/**
 * 4. Página de ajustes con multitud de opciones, incluyendo "máxima longitud de texto".
 */
function mbp_pagina_ajustes() {
    if ( ! current_user_can('manage_options') ) {
        return;
    }

    // Valores por defecto
    $settings_defaults = array(
        'etiqueta_titulo'    => 'h2',
        'alineacion_img'     => 'left',
        'ancho_img'          => '200',
        'alto_img'           => 'auto',
        'layout'             => 'grid',       // 'grid' o 'list'
        'columns'            => 3,
        'background_color'   => '#ffffff',
        'text_color'         => '#333333',
        'title_color'        => '#000000',
        'title_font'         => 'Arial',
        'content_font'       => 'Arial',
        'button_text'        => 'Ver más',
        'button_bg_color'    => '#0073aa',
        'button_txt_color'   => '#ffffff',
        'card_width'         => 'auto',
        'card_height'        => 'auto',
        'title_alignment'    => 'left',
        'content_alignment'  => 'left',
        'button_alignment'   => 'left',
        'title_font_size'    => '24',
        'content_font_size'  => '16',
        'card_padding'       => '20',
        'card_margin_bottom' => '20',
        'max_text_length'    => '100',  // <--- NUEVO: máximo de caracteres en tarjeta
    );

    // Leer de la BD
    $settings = get_option('mbp_settings', array());
    $settings = wp_parse_args($settings, $settings_defaults);

    // Lista de fuentes disponibles (incluyendo Google Fonts)
    $fuentes_disponibles = array(
        'Arial'            => 'Arial (Sistema)',
        'Georgia'          => 'Georgia (Sistema)',
        'Times New Roman'  => 'Times New Roman (Sistema)',
        'Open Sans'        => 'Open Sans (Google)',
        'Roboto'           => 'Roboto (Google)',
        'Lato'             => 'Lato (Google)',
        'Montserrat'       => 'Montserrat (Google)',
        'Poppins'          => 'Poppins (Google)',
        'Raleway'          => 'Raleway (Google)',
        'Oswald'           => 'Oswald (Google)'
    );

    // Alineaciones
    $opciones_alineacion = array(
        'left'    => __('Izquierda', 'mi-blog-personal'),
        'center'  => __('Centrada', 'mi-blog-personal'),
        'right'   => __('Derecha', 'mi-blog-personal'),
        'justify' => __('Justificada', 'mi-blog-personal'),
    );
    ?>
    <div class="wrap">
        <h1><?php _e('Ajustes de Mi Blog Personal', 'mi-blog-personal'); ?></h1>

        <form method="post" action="options.php">
            <?php settings_fields('mbp_ajustes_grupo'); ?>

            <table class="form-table">
                <!-- Etiqueta del título (HTML) -->
                <tr>
                    <th scope="row">
                        <label for="etiqueta_titulo"><?php _e('Etiqueta del título (HTML)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <select name="mbp_settings[etiqueta_titulo]" id="etiqueta_titulo">
                            <?php 
                            $etiquetas = array('h1','h2','h3','h4','h5','h6');
                            foreach($etiquetas as $et){
                                $selected = ($et === $settings['etiqueta_titulo']) ? 'selected' : '';
                                echo "<option value='$et' $selected>$et</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>

                <!-- Alineación de la imagen destacada -->
                <tr>
                    <th scope="row">
                        <label for="alineacion_img"><?php _e('Alineación de la imagen', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <select name="mbp_settings[alineacion_img]" id="alineacion_img">
                            <?php 
                            $img_align_options = array(
                                'left'   => __('Izquierda', 'mi-blog-personal'),
                                'center' => __('Centrada', 'mi-blog-personal'),
                                'right'  => __('Derecha', 'mi-blog-personal'),
                                'none'   => __('Sin alineación', 'mi-blog-personal')
                            );
                            foreach($img_align_options as $val => $label){
                                $selected = ($val === $settings['alineacion_img']) ? 'selected' : '';
                                echo "<option value='$val' $selected>$label</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>

                <!-- Tamaño imagen destacada -->
                <tr>
                    <th scope="row">
                        <label for="ancho_img"><?php _e('Ancho de la imagen (px)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="mbp_settings[ancho_img]" id="ancho_img" 
                               value="<?php echo esc_attr($settings['ancho_img']); ?>" 
                               style="width:80px;" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="alto_img"><?php _e('Alto de la imagen (px)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="mbp_settings[alto_img]" id="alto_img"
                               value="<?php echo esc_attr($settings['alto_img']); ?>"
                               style="width:80px;" />
                    </td>
                </tr>

                <!-- Layout -->
                <tr>
                    <th scope="row">
                        <label for="layout"><?php _e('Estilo de listado', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <select name="mbp_settings[layout]" id="layout">
                            <option value="grid" <?php selected($settings['layout'], 'grid'); ?>>
                                <?php _e('Cuadrícula', 'mi-blog-personal'); ?>
                            </option>
                            <option value="list" <?php selected($settings['layout'], 'list'); ?>>
                                <?php _e('Lista', 'mi-blog-personal'); ?>
                            </option>
                        </select>
                    </td>
                </tr>

                <!-- Columnas (grid) -->
                <tr>
                    <th scope="row">
                        <label for="columns"><?php _e('Número de columnas (grid)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="number" min="1" max="6" name="mbp_settings[columns]" id="columns"
                               value="<?php echo esc_attr($settings['columns']); ?>"
                               style="width:60px;" />
                    </td>
                </tr>

                <!-- Colores (fondo, texto, título) -->
                <tr>
                    <th scope="row">
                        <label for="background_color"><?php _e('Color de fondo tarjeta', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="color" name="mbp_settings[background_color]" id="background_color"
                               value="<?php echo esc_attr($settings['background_color']); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="text_color"><?php _e('Color de texto', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="color" name="mbp_settings[text_color]" id="text_color"
                               value="<?php echo esc_attr($settings['text_color']); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="title_color"><?php _e('Color del título', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="color" name="mbp_settings[title_color]" id="title_color"
                               value="<?php echo esc_attr($settings['title_color']); ?>" />
                    </td>
                </tr>

                <!-- Fuentes (título y contenido) -->
                <tr>
                    <th scope="row">
                        <label for="title_font"><?php _e('Fuente para títulos', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <select name="mbp_settings[title_font]" id="title_font">
                            <?php
                            foreach($fuentes_disponibles as $fuente => $label){
                                $selected = ($fuente === $settings['title_font']) ? 'selected' : '';
                                echo "<option value='$fuente' $selected>$label</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="content_font"><?php _e('Fuente para contenido', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <select name="mbp_settings[content_font]" id="content_font">
                            <?php
                            foreach($fuentes_disponibles as $fuente => $label){
                                $selected = ($fuente === $settings['content_font']) ? 'selected' : '';
                                echo "<option value='$fuente' $selected>$label</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>

                <!-- Tamaño de fuente (título y contenido) -->
                <tr>
                    <th scope="row">
                        <label for="title_font_size"><?php _e('Tamaño de fuente del título (px)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="mbp_settings[title_font_size]" id="title_font_size"
                               value="<?php echo esc_attr($settings['title_font_size']); ?>"
                               style="width:60px;" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="content_font_size"><?php _e('Tamaño de fuente del contenido (px)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="mbp_settings[content_font_size]" id="content_font_size"
                               value="<?php echo esc_attr($settings['content_font_size']); ?>"
                               style="width:60px;" />
                    </td>
                </tr>

                <!-- Botón "Ver más" -->
                <tr>
                    <th scope="row">
                        <label for="button_text"><?php _e('Texto del botón "Ver más"', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="mbp_settings[button_text]" id="button_text"
                               value="<?php echo esc_attr($settings['button_text']); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="button_bg_color"><?php _e('Color de fondo del botón', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="color" name="mbp_settings[button_bg_color]" id="button_bg_color"
                               value="<?php echo esc_attr($settings['button_bg_color']); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="button_txt_color"><?php _e('Color de texto del botón', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="color" name="mbp_settings[button_txt_color]" id="button_txt_color"
                               value="<?php echo esc_attr($settings['button_txt_color']); ?>" />
                    </td>
                </tr>

                <!-- Alineación de título, contenido, botón -->
                <tr>
                    <th scope="row">
                        <label for="title_alignment"><?php _e('Alineación del Título', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <select name="mbp_settings[title_alignment]" id="title_alignment">
                            <?php
                            foreach($opciones_alineacion as $val => $label){
                                $selected = ($val === $settings['title_alignment']) ? 'selected' : '';
                                echo "<option value='$val' $selected>$label</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="content_alignment"><?php _e('Alineación del Contenido', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <select name="mbp_settings[content_alignment]" id="content_alignment">
                            <?php
                            foreach($opciones_alineacion as $val => $label){
                                $selected = ($val === $settings['content_alignment']) ? 'selected' : '';
                                echo "<option value='$val' $selected>$label</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="button_alignment"><?php _e('Alineación del Botón', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <select name="mbp_settings[button_alignment]" id="button_alignment">
                            <?php
                            foreach($opciones_alineacion as $val => $label){
                                $selected = ($val === $settings['button_alignment']) ? 'selected' : '';
                                echo "<option value='$val' $selected>$label</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>

                <!-- Tamaño de la tarjeta (ancho y alto) -->
                <tr>
                    <th scope="row">
                        <label for="card_width"><?php _e('Ancho de la tarjeta (px)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="mbp_settings[card_width]" id="card_width"
                               value="<?php echo esc_attr($settings['card_width']); ?>"
                               style="width:80px;" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="card_height"><?php _e('Alto de la tarjeta (px)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="mbp_settings[card_height]" id="card_height"
                               value="<?php echo esc_attr($settings['card_height']); ?>"
                               style="width:80px;" />
                    </td>
                </tr>

                <!-- Padding / margen de la tarjeta -->
                <tr>
                    <th scope="row">
                        <label for="card_padding"><?php _e('Padding interno de la tarjeta (px)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="mbp_settings[card_padding]" id="card_padding"
                               value="<?php echo esc_attr($settings['card_padding']); ?>"
                               style="width:60px;" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="card_margin_bottom"><?php _e('Margen inferior de la tarjeta (px)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="mbp_settings[card_margin_bottom]" id="card_margin_bottom"
                               value="<?php echo esc_attr($settings['card_margin_bottom']); ?>"
                               style="width:60px;" />
                    </td>
                </tr>

                <!-- NUEVO: Máxima longitud del texto en la tarjeta -->
                <tr>
                    <th scope="row">
                        <label for="max_text_length"><?php _e('Máxima longitud de texto en la tarjeta (caracteres)', 'mi-blog-personal'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="mbp_settings[max_text_length]" id="max_text_length"
                               value="<?php echo esc_attr($settings['max_text_length']); ?>"
                               style="width:60px;" />
                        <p class="description">
                            <?php _e('Si el contenido supera este número, se mostrará un extracto seguido de "...".', 'mi-blog-personal'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

/**
 * 5. Cargar Google Fonts si procede.
 */
function mbp_cargar_google_fonts() {
    $settings = get_option('mbp_settings', array());
    if( ! is_array($settings) ) {
        return;
    }

    // Lista de Google Fonts
    $google_fonts = array('Open Sans','Roboto','Lato','Montserrat','Poppins','Raleway','Oswald');

    $fuentes_a_cargar = array();

    if( !empty($settings['title_font']) && in_array($settings['title_font'], $google_fonts) ) {
        $fuentes_a_cargar[] = $settings['title_font'];
    }
    if( !empty($settings['content_font']) && in_array($settings['content_font'], $google_fonts) ) {
        $fuentes_a_cargar[] = $settings['content_font'];
    }

    $fuentes_a_cargar = array_unique($fuentes_a_cargar);
    if( empty($fuentes_a_cargar) ) return;

    $familias = array();
    foreach($fuentes_a_cargar as $f){
        $familias[] = str_replace(' ', '+', $f).':400,700';
    }
    $query_fonts = implode('|', $familias);

    wp_enqueue_style(
        'mbp-google-fonts',
        'https://fonts.googleapis.com/css?family='.$query_fonts,
        array(),
        null
    );
}
add_action('wp_enqueue_scripts', 'mbp_cargar_google_fonts');

/**
 * 6. Shortcode [mi_blog] para mostrar las tarjetas (con extracto).
 */
function mbp_shortcode_blog($atts) {
    // Defaults
    $defaults = array(
        'etiqueta_titulo'    => 'h2',
        'alineacion_img'     => 'left',
        'ancho_img'          => '200',
        'alto_img'           => 'auto',
        'layout'             => 'grid',
        'columns'            => 3,
        'background_color'   => '#ffffff',
        'text_color'         => '#333333',
        'title_color'        => '#000000',
        'title_font'         => 'Arial',
        'content_font'       => 'Arial',
        'button_text'        => 'Ver más',
        'button_bg_color'    => '#0073aa',
        'button_txt_color'   => '#ffffff',
        'card_width'         => 'auto',
        'card_height'        => 'auto',
        'title_alignment'    => 'left',
        'content_alignment'  => 'left',
        'button_alignment'   => 'left',
        'title_font_size'    => '24',
        'content_font_size'  => '16',
        'card_padding'       => '20',
        'card_margin_bottom' => '20',
        'max_text_length'    => '100',
    );

    // Mezclar con ajustes guardados
    $settings = get_option('mbp_settings', array());
    $settings = wp_parse_args($settings, $defaults);

    // Query CPT
    $args = array(
        'post_type'      => 'mi_blog',
        'posts_per_page' => -1,
        'post_status'    => 'publish'
    );
    $query = new WP_Query($args);

    ob_start();
    ?>
    <style>
        .mbp-listado {
            display: grid;
            grid-template-columns: repeat(<?php echo max(1, (int)$settings['columns']); ?>, 1fr);
            gap: 20px;
        }

        .mbp-entry {
            background-color: <?php echo esc_attr($settings['background_color']); ?>;
            color: <?php echo esc_attr($settings['text_color']); ?>;
            padding: <?php echo intval($settings['card_padding']); ?>px;
            margin-bottom: <?php echo intval($settings['card_margin_bottom']); ?>px;
            border: 1px solid #ddd;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            border-radius: 8px;
            font-family: '<?php echo esc_attr($settings['content_font']); ?>', sans-serif;
            position: relative;
            overflow: hidden;
        }

        .mbp-entry img {
            max-width: 100%;
            display: block;
            border-radius: 8px 8px 0 0;
        }

        /* 🌍 RESPONSIVE DESIGN 🌍 */
        @media (max-width: 1024px) {
            .mbp-listado {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .mbp-listado {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <div class="mbp-listado">
    <?php
    if ($query->have_posts()) :
        while ($query->have_posts()) : $query->the_post();

            // Campos
            $titulo  = get_the_title();
            $et      = esc_html($settings['etiqueta_titulo']);
            $t_align = esc_attr($settings['title_alignment']);
            $c_align = esc_attr($settings['content_alignment']);
            $b_align = esc_attr($settings['button_alignment']);

            // Imagen destacada
            $img_html = '';
            if (has_post_thumbnail()) {
                $img_id   = get_post_thumbnail_id();
                $img_url  = wp_get_attachment_image_url($img_id, 'full');

                $alineacion = esc_attr($settings['alineacion_img']);
                $ancho      = esc_attr($settings['ancho_img']);
                $alto       = esc_attr($settings['alto_img']);

                $estilo_img = "display: block; max-width: 100%;";

                // Aplicar ancho y alto personalizados solo si no están en "auto"
                if ($ancho !== 'auto') {
                    $estilo_img .= " width: {$ancho}px;";
                }
                if ($alto !== 'auto') {
                    $estilo_img .= " height: {$alto}px; object-fit: cover;";
                }

                // Alineación de la imagen
                switch ($alineacion) {
                    case 'left':
                        $estilo_img .= " float: left; margin: 0 15px 15px 0;";
                        break;
                    case 'center':
                        $estilo_img .= " margin: 0 auto 15px auto; display: block;";
                        break;
                    case 'right':
                        $estilo_img .= " float: right; margin: 0 0 15px 15px;";
                        break;
                }

                $img_html = "<img src='{$img_url}' alt='".esc_attr($titulo)."' style='{$estilo_img}' />";
            }

            // Extra: Limitar texto
            $max_len = (int)$settings['max_text_length'];
            $full_text = get_the_content();
            $short_text = (mb_strlen(strip_tags($full_text)) > $max_len) ? mb_substr(strip_tags($full_text), 0, $max_len) . '...' : strip_tags($full_text);

            // Botón
            $post_link = get_permalink();
            ?>
            <div class="mbp-entry">
                
                <<?php echo $et; ?> class="mbp-title" style="text-align: <?php echo $t_align; ?>;
                    font-family:'<?php echo esc_attr($settings['title_font']); ?>', sans-serif;
                    font-size: <?php echo intval($settings['title_font_size']); ?>px;
                    color: <?php echo esc_attr($settings['title_color']); ?>;">
                    <?php echo esc_html($titulo); ?>
                </<?php echo $et; ?>>

                <?php echo $img_html; ?>

                <div class="mbp-content" style="text-align: <?php echo $c_align; ?>;
                    font-size: <?php echo intval($settings['content_font_size']); ?>px;">
                    <?php echo esc_html($short_text); ?>
                </div>

                <div class="mbp-button-container" style="text-align: <?php echo $b_align; ?>; margin-top:15px;">
                    <a href="<?php echo esc_url($post_link); ?>" 
                       style="display:inline-block; padding:10px 20px; 
                              background-color:<?php echo esc_attr($settings['button_bg_color']); ?>; 
                              color:<?php echo esc_attr($settings['button_txt_color']); ?>; 
                              text-decoration:none; border-radius:4px;">
                        <?php echo esc_html($settings['button_text']); ?>
                    </a>
                </div>
            </div>
            <?php

        endwhile;
    else:
        echo '<p>' . __('No hay entradas disponibles en este momento.', 'mi-blog-personal') . '</p>';
    endif;
    ?>
    </div> <!-- .mbp-listado -->
    <?php

    wp_reset_postdata();

    return ob_get_clean();
}
add_shortcode('mi_blog', 'mbp_shortcode_blog');


/**
 * 7. Activación y desactivación: regenerar reglas.
 */
function mbp_plugin_activacion() {
    mbp_registrar_cpt_blog();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'mbp_plugin_activacion');

function mbp_plugin_desactivacion() {
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'mbp_plugin_desactivacion');

/**
 * 8. Plantilla personalizada para ver el detalle (single).
 *    Generamos un archivo temporal si no existe ya, mostrando título, imagen, y contenido completo.
 */
function mbp_single_template($single_template) {
    global $post;
    if ( $post->post_type === 'mi_blog' ) {
        // Recupera los ajustes guardados, y si no existen, se usan estos defaults:
        $defaults = array(
            'title_alignment'   => 'center',
            'content_alignment' => 'left',
            'title_font'        => 'Pathway Extreme',  // Usamos la fuente "Pathway Extreme"
            'content_font'      => 'Pathway Extreme',  // Usamos la misma fuente para el contenido
            'title_font_size'   => '34',
            'content_font_size' => '16',
            'title_color'       => '#000000',
            'background_color'  => '#f9f9f9'
        );
        $settings = wp_parse_args(get_option('mbp_settings', array()), $defaults);

        // Prepara la ruta de la carpeta temporal en "uploads"
        $upload_dir = wp_upload_dir();
        $temp_dir   = $upload_dir['basedir'] . '/mbp-tpl';
        if ( ! file_exists($temp_dir) ) {
            @mkdir($temp_dir, 0755, true);
        }
        $temp_file = $temp_dir . '/single-mi_blog.php';

        // Escapa y define las variables para usarlas en la plantilla
        $title_align   = esc_attr($settings['title_alignment']);
        $content_align = esc_attr($settings['content_alignment']);
        $title_font    = esc_attr($settings['title_font']);
        $content_font  = esc_attr($settings['content_font']);
        $title_size    = intval($settings['title_font_size']);
        $content_size  = intval($settings['content_font_size']);
        $title_color   = esc_attr($settings['title_color']);
        $bg_color      = esc_attr($settings['background_color']);

        // Generamos el código HTML y CSS de la plantilla
        $template_code  = "<?php get_header(); ?>\n";
        $template_code .= "<style>
            /* Estilos para la plantilla single generada por el plugin */
            .mbp-single-container {
                background-color: {$bg_color};
                padding: 40px;
                margin: 20px auto;
                max-width: 900px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                border-radius: 8px;
            }
            .mbp-single-title {
                text-align: {$title_align};
                font-family: '{$title_font}', sans-serif;
                font-size: {$title_size}px;
                color: {$title_color};
                margin-top: 3%;  /* Margen superior del 3% */
                margin-bottom: 20px;
            }
            .mbp-single-content {
                text-align: {$content_align};
                font-family: '{$content_font}', sans-serif;
                font-size: {$content_size}px;
                line-height: 1.6;
            }
            .mbp-single-image {
                text-align: center;
                margin-bottom: 30px;
            }
            .mbp-single-image img {
                max-width: 100%;
                height: auto;
                border-radius: 8px;
            }
        </style>\n";
        $template_code .= "<div class='mbp-single-container'>\n";
        $template_code .= "  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>\n";
        $template_code .= "    <h1 class='mbp-single-title'><?php the_title(); ?></h1>\n";
        $template_code .= "    <div class='mbp-single-image'>\n";
        $template_code .= "      <?php if ( has_post_thumbnail() ) { the_post_thumbnail('large'); } ?>\n";
        $template_code .= "    </div>\n";
        $template_code .= "    <div class='mbp-single-content'><?php the_content(); ?></div>\n";
        $template_code .= "  <?php endwhile; endif; ?>\n";
        $template_code .= "</div>\n";
        $template_code .= "<?php get_footer(); ?>\n";

        // Escribe (o reescribe) el archivo de la plantilla
        @file_put_contents($temp_file, $template_code);

        return $temp_file;
    }
    return $single_template;
}
add_filter('single_template', 'mbp_single_template');

