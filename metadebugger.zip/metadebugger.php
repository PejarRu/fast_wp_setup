<?php
/*
Plugin Name: Savour Meta Debugger
Description: Plugin para listar posts de un post type y depurar sus metadatos.
Version: 1.0
Author: Alex Parra
Text Domain: savour-meta-debugger
*/

// Evitar acceso directo
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * 1) Añadimos un menú "Meta Debugger" en el Escritorio
 */
function savour_meta_debugger_menu() {
    add_menu_page(
        'Meta Debugger',
        'Meta Debugger',
        'manage_options',
        'savour-meta-debugger',
        'savour_meta_debugger_page_callback',
        'dashicons-search',
        90
    );
}
add_action('admin_menu', 'savour_meta_debugger_menu');

/**
 * 2) Callback para renderizar la página de administración
 */
function savour_meta_debugger_page_callback() {
    if ( ! current_user_can('manage_options') ) {
        wp_die('No tienes permisos suficientes para acceder aquí.');
    }

    // Guardaremos aquí la info de la vista:
    $selected_post_type = '';
    $posts_found        = [];
    $meta_for_post      = null;
    $meta_post_title    = null;

    // 2.1) Si viene action=meta, es que el usuario ha pulsado "Ver Metadatos"
    if ( isset($_GET['action']) && $_GET['action'] === 'meta' && isset($_GET['post_id']) ) {
        $post_id = absint($_GET['post_id']);
        $the_post = get_post($post_id);
        if ($the_post) {
            $meta_for_post   = get_post_meta($the_post->ID);
            $meta_post_title = $the_post->post_title . " (ID {$the_post->ID})";
        }
    }

    // 2.2) Si el usuario ha seleccionado un post type en el formulario:
    if ( isset($_POST['savour_post_type_submit']) ) {
        $selected_post_type = sanitize_text_field($_POST['savour_post_type']);
        if ( post_type_exists($selected_post_type) ) {
            $args = [
                'post_type'      => $selected_post_type,
                'post_status'    => 'any',
                'posts_per_page' => -1,
            ];
            $query = new WP_Query($args);
            $posts_found = $query->posts;
        }
    }

    // 2.3) Listado de todos los post types (públicos y no públicos). 
    // Si quisieras filtrar solo públicos, puedes usar get_post_types(['public'=>true]).
    $all_post_types = get_post_types([], 'objects');
    ?>
    <div class="wrap">
        <h1>Meta Debugger</h1>

        <!-- Form para seleccionar un post type -->
        <form method="POST" action="">
            <label for="savour_post_type">Selecciona un post type:</label>
            <select name="savour_post_type" id="savour_post_type">
                <option value="">-- Elige --</option>
                <?php
                foreach ($all_post_types as $pt_slug => $pt_obj) {
                    // $pt_obj->label o ->labels->name
                    // Evitar post types "revision", "nav_menu_item", etc. si no los quieres
                    if ( in_array($pt_slug, ['revision','nav_menu_item','custom_css','customize_changeset','oembed_cache','user_request','wp_block','wp_template','wp_template_part']) ) {
                        continue;
                    }
                    $selected = selected($selected_post_type, $pt_slug, false);
                    echo "<option value='{$pt_slug}' {$selected}>{$pt_obj->labels->name} ({$pt_slug})</option>";
                }
                ?>
            </select>
            <?php submit_button('Mostrar Posts', 'primary', 'savour_post_type_submit', false); ?>
        </form>

        <?php 
        // 2.4) Si tenemos posts encontrados, los listamos en una tabla
        if (! empty($posts_found)) : ?>
            <h2>Posts encontrados (<?php echo esc_html($selected_post_type); ?>)</h2>
            <table class="widefat fixed striped" style="max-width:700px;">
                <thead>
                    <tr>
                        <th style="width:60px;">ID</th>
                        <th>Título</th>
                        <th style="width:100px;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($posts_found as $p) : ?>
                    <tr>
                        <td><?php echo $p->ID; ?></td>
                        <td><?php echo esc_html($p->post_title); ?></td>
                        <td>
                            <a href="<?php echo add_query_arg(['page'=>'savour-meta-debugger','action'=>'meta','post_id'=>$p->ID], admin_url('admin.php')); ?>">
                                Ver metadatos
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <?php 
        // 2.5) Si el usuario ha solicitado ver meta de un post concreto
        if ($meta_for_post !== null) : ?>
            <h2>Metadatos de: <?php echo esc_html($meta_post_title); ?></h2>
            <pre style="background: #222; color: #eee; padding: 15px; max-height:400px; overflow:auto;">
                <?php print_r($meta_for_post); ?>
            </pre>
        <?php endif; ?>

    </div>
    <?php
}
