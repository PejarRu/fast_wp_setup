import * as cmpstub from '@iabtcf/stub';

/**
 * initialize the __tcfapi function and post message
 * https://github.com/InteractiveAdvertisingBureau/iabtcf-es/tree/master/modules/stub
 */
cmpstub();
