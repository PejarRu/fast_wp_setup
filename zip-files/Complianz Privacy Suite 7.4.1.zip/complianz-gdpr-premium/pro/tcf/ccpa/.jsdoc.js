module.exports = {
  source: {
    include: [
      'README.md',
      'src/uspapi.js',
    ],
  },
  opts: {
    destination: 'docs/',
  },
};
