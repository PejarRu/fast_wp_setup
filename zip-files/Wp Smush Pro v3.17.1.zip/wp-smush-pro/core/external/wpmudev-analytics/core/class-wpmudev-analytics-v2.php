<?php

if ( ! class_exists( 'WPMUDEV_Analytics_V2' ) ) {
	class WPMUDEV_Analytics_V2 extends WPMUDEV_Analytics_V4 {
	}
}