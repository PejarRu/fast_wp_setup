<?php

if ( ! class_exists( 'WPMUDEV_Analytics_V3' ) ) {
	class WPMUDEV_Analytics_V3 extends WPMUDEV_Analytics_V4 {
	}
}