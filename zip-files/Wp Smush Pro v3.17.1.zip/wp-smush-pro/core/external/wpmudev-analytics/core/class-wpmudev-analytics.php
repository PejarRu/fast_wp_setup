<?php

if ( ! class_exists( 'WPMUDEV_Analytics' ) ) {
	class WPMUDEV_Analytics extends WPMUDEV_Analytics_V4 {
	}
}