<?php

namespace Smush_Vendor\GuzzleHttp\Exception;

use Smush_Vendor\Psr\Http\Client\ClientExceptionInterface;
interface GuzzleException extends ClientExceptionInterface
{
}