<?php

namespace Smush_Vendor;

// Don't redefine the functions if included multiple times.
if (!\function_exists('Smush_Vendor\\GuzzleHttp\\describe_type')) {
    require __DIR__ . '/functions.php';
}