// Register CherryX Global Vue Components
window.cxVueUi.registerGlobalComponents( Vue );

// Register CherryX Global Extensions
window.cxVueUi.registerGlobalExtensions();

