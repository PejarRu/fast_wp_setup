<?php
/**
 * Active filter remove template
 */

?>
<div class="jet-active-filter__remove">&times;</div>