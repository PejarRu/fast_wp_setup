<?php
/**
 * Active tag label template
 */

?>
<div class="jet-active-tag__label">/% $value %/<span class="jet-active-tag__label-separator">:</span></div>