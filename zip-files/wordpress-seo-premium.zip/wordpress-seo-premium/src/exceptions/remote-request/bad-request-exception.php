<?php

namespace Yoast\WP\SEO\Premium\Exceptions\Remote_Request;

/**
 * Class to manage a 400 - Bad request response.
 */
class Bad_Request_Exception extends Remote_Request_Exception {

}
