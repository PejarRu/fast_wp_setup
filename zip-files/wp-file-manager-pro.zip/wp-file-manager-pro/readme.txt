=== File Manager ===
Contributors: mndpsingh287
Tags: file manager, upload files, WP file manager, file manage, edit files, delete files, ftp, filemanager, wpfilemanager, clone, move, zip, download, modify, edit, manage, directory
Requires at least: 3.4
Tested up to: 6.8.1
Stable tag: 8.4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

File Manager provides you features to edit, delete, upload, download, copy and paste files and folders.

== Description ==

#### File Manager provides you features to edit, delete, upload, download, copy and paste files and folders. You can easily copy, move files folder or any files from one location to another location.

== Installation ==

1. Upload the `wp-file-manager` folder to the directory `/wp-content/plugins/`.
2. Activate the plugin using the 'Plugins' menu in WordPress.

== Frequently asked questions ==

= Can we make zip of any folder or file and download it ? =
Yes, You can archieve any files and folders as zip then simple download it. Please view screenshots.

= Support = 
* If any problem occurs, please create a ticket at https://filemanagerpro.io/contact/.

## How to use

1. First Activate Plugin.
2. Then Click on " WP File Manager " menu. Then do with files what you want to do.

== Screenshots ==

1. File Manager File View Screen.
2. Make a folder or file archive as zip.
3. Download archived zip file.

== Other Notes ==

== Minimum requirements for File Manager PRO ==
*   Wordpress 3.3+
*   PHP 5.x
*   MySQL 5.x
