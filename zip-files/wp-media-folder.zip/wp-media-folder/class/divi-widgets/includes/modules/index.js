import WpmfPdfEmbedDivi from './PdfEmbed/PdfEmbed';
import WpmfFileDesignDivi from './FileDesign/FileDesign';
import WpmfGalleryDivi from './Gallery/Gallery';
import WpmfGalleryAddonDivi from "./GalleryAddon/GalleryAddon";
export default [WpmfPdfEmbedDivi, WpmfFileDesignDivi, WpmfGalleryDivi, WpmfGalleryAddonDivi];