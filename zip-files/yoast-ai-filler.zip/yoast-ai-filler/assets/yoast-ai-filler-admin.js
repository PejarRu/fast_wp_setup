(function () {
  if (!window.YoastAiFiller) return;

  const nonce = window.YoastAiFiller.nonce;
  const endpoint = window.YoastAiFiller.endpoint_single || window.YoastAiFiller.endpoint;
  const endpoint_bulk = window.YoastAiFiller.endpoint_bulk;

  if (!endpoint) {
    console.error("[Yoast AI Filler] endpoint_single/endpoint no definido");
    return;
  }

  if (!(window.wp && wp.plugins && wp.editPost && wp.data && wp.element && wp.components)) return;

  const { registerPlugin } = wp.plugins;
  const { PluginDocumentSettingPanel } = wp.editPost;
  const { Button, Notice, TextControl, TextareaControl, CheckboxControl } = wp.components;
  const { useState } = wp.element;
  const { select } = wp.data;

  const Panel = () => {
    const [isBusy, setIsBusy] = useState(false);
    const [msg, setMsg] = useState(null);
    const [msgType, setMsgType] = useState("info");

    const [keyword, setKeyword] = useState("");
    const [extra, setExtra] = useState("");

    const [bulkKeyword, setBulkKeyword] = useState("");
    const [bulkContext, setBulkContext] = useState("");
    const [overwrite, setOverwrite] = useState(true);

    const postId = select("core/editor")?.getCurrentPostId?.();

    const runSingle = async () => {
      setIsBusy(true);
      setMsg("Generando SEO para esta página…");
      setMsgType("info");

      try {
        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-WP-Nonce": nonce },
          body: JSON.stringify({ post_id: postId, keyword: keyword || "", extra_context: extra || "" }),
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data?.error || "Error desconocido");

        setMsg("Guardado en Yoast. (Si no actualiza, recarga).");
        setMsgType("success");
      } catch (e) {
        setMsg("Error: " + (e.message || e));
        setMsgType("error");
      } finally {
        setIsBusy(false);
      }
    };

    const runBulk = async () => {
      if (!endpoint_bulk) {
        setMsg("No se encontró endpoint_bulk. Reinstala/actualiza el plugin.");
        setMsgType("error");
        return;
      }

      setIsBusy(true);
      setMsg("Generando SEO para TODAS las páginas… (se hace en lotes)");
      setMsgType("info");

      try {
        const res = await fetch(endpoint_bulk, {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-WP-Nonce": nonce },
          body: JSON.stringify({ bulk_keyword: bulkKeyword || "", global_context: bulkContext || "", overwrite: !!overwrite }),
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data?.error || "Error desconocido");

        setMsg(`Listo ✅ Páginas actualizadas: ${data.saved_count} (lotes: ${data.batches})`);
        setMsgType("success");
      } catch (e) {
        setMsg("Error: " + (e.message || e));
        setMsgType("error");
      } finally {
        setIsBusy(false);
      }
    };

    return wp.element.createElement(
      PluginDocumentSettingPanel,
      { name: "yoast-ai-filler", title: "Yoast AI Filler" },
      msg ? wp.element.createElement(Notice, { status: msgType, isDismissible: true }, msg) : null,

      wp.element.createElement(TextControl, {
        label: "Keyword objetivo (esta página)",
        value: keyword,
        onChange: setKeyword,
      }),
      wp.element.createElement(TextareaControl, {
        label: "Contexto extra (esta página)",
        value: extra,
        onChange: setExtra,
      }),
      wp.element.createElement(
        Button,
        { isPrimary: true, isBusy, disabled: !postId || isBusy, onClick: runSingle },
        "Generar SEO (solo esta página)"
      ),

      wp.element.createElement("hr", null),

      wp.element.createElement(TextControl, {
        label: "Frase clave objetivo (base) - todas las páginas",
        value: bulkKeyword,
        onChange: setBulkKeyword,
        help: "Ej: jardinería Mallorca (se adapta por página: contacto/servicios/…).",
      }),
      wp.element.createElement(TextareaControl, {
        label: "Contexto global (todas las páginas)",
        value: bulkContext,
        onChange: setBulkContext,
        help: "Ej: Bernadi Cabanellas (Mallorca), jardinero. Servicios: mantenimiento, poda…",
      }),
      wp.element.createElement(CheckboxControl, {
        label: "Sobrescribir existentes",
        checked: overwrite,
        onChange: setOverwrite,
      }),
      wp.element.createElement(
        Button,
        { isSecondary: true, isBusy, disabled: isBusy, onClick: runBulk },
        "Generar SEO para TODAS las páginas"
      )
    );
  };

  registerPlugin("yoast-ai-filler", { render: Panel });
})();