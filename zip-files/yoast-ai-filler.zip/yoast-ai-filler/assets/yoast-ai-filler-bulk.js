(function () {
  if (!window.YoastAiFiller) return;

  const btn = document.getElementById("yoast-ai-bulk-run");
  const status = document.getElementById("yoast-ai-bulk-status");
  const logEl = document.getElementById("yoast-ai-bulk-log");
  const kwEl = document.getElementById("yoast-ai-bulk-keyword");
  const ctxEl = document.getElementById("yoast-ai-bulk-context");
  const overwriteEl = document.getElementById("yoast-ai-bulk-overwrite");

  if (!btn || !status || !logEl) return;

  const nonce = window.YoastAiFiller.nonce;
  const endpoint_bulk = window.YoastAiFiller.endpoint_bulk;

  if (!endpoint_bulk) {
    console.error("[Yoast AI Filler] endpoint_bulk no definido");
    return;
  }

  function setLog(lines) {
    logEl.style.display = "block";
    logEl.textContent = Array.isArray(lines) ? lines.join("\n") : String(lines || "");
  }

  async function postJson(url, payload) {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-WP-Nonce": nonce },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || "Error desconocido");
    return data;
  }

  btn.addEventListener("click", async (e) => {
    e.preventDefault();

    btn.disabled = true;
    status.textContent = "Generando SEO para todas las páginas… (se hace en lotes)";
    setLog("");

    try {
      const data = await postJson(endpoint_bulk, {
        bulk_keyword: (kwEl && kwEl.value) ? kwEl.value : "",
        global_context: (ctxEl && ctxEl.value) ? ctxEl.value : "",
        overwrite: !!(overwriteEl && overwriteEl.checked),
      });

      status.textContent = `Listo ✅ Páginas actualizadas: ${data.saved_count} (lotes: ${data.batches})`;
      setLog([...(data.log || []), data.note || ""].filter(Boolean));
    } catch (err) {
      status.textContent = "Error ❌";
      setLog(err.message || String(err));
    } finally {
      btn.disabled = false;
    }
  });
})();