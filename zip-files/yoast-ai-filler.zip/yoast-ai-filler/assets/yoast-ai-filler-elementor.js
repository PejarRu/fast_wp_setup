(function () {
  if (!window.YoastAiFiller) return;

  const nonce = window.YoastAiFiller.nonce;
  const endpoint = window.YoastAiFiller.endpoint_single || window.YoastAiFiller.endpoint;
  const endpoint_bulk = window.YoastAiFiller.endpoint_bulk;

  if (!endpoint) {
    console.error("[Yoast AI Filler] endpoint_single/endpoint no definido");
    return;
  }

  function getPostId() {
    try {
      if (window.elementor && elementor.config?.document?.id) return parseInt(elementor.config.document.id, 10);
    } catch (e) {}
    try {
      const url = new URL(window.location.href);
      const p = url.searchParams.get("post") || url.searchParams.get("post_id") || url.searchParams.get("id");
      return p ? parseInt(p, 10) : null;
    } catch (e) {}
    return null;
  }

  function createUI() {
    const wrap = document.createElement("div");
    wrap.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:999999;max-width:390px;font-family:inherit;";

    const card = document.createElement("div");
    card.style.cssText = "background:#fff;border:1px solid rgba(0,0,0,.12);border-radius:12px;padding:12px;box-shadow:0 6px 18px rgba(0,0,0,.14);";

    const title = document.createElement("div");
    title.textContent = "Yoast AI Filler";
    title.style.cssText = "font-weight:800;margin-bottom:8px;";

    const kw = document.createElement("input");
    kw.placeholder = "Keyword objetivo (esta página)";
    kw.style.cssText = "width:100%;padding:8px 10px;border:1px solid rgba(0,0,0,.2);border-radius:10px;margin-bottom:8px;";

    const extra = document.createElement("textarea");
    extra.placeholder = "Contexto extra (esta página)";
    extra.rows = 3;
    extra.style.cssText = "width:100%;padding:8px 10px;border:1px solid rgba(0,0,0,.2);border-radius:10px;resize:vertical;margin-bottom:10px;";

    const btnSingle = document.createElement("button");
    btnSingle.type = "button";
    btnSingle.textContent = "Generar SEO (esta página)";
    btnSingle.style.cssText = "width:100%;background:#2271b1;color:#fff;border:none;border-radius:10px;padding:10px 12px;cursor:pointer;font-weight:800;margin-bottom:8px;";

    const sep = document.createElement("div");
    sep.style.cssText = "height:1px;background:rgba(0,0,0,.1);margin:10px 0;";

    const bulkKeyword = document.createElement("input");
    bulkKeyword.placeholder = "Frase clave objetivo (base) - todas";
    bulkKeyword.style.cssText = "width:100%;padding:8px 10px;border:1px solid rgba(0,0,0,.2);border-radius:10px;margin-bottom:8px;";

    const bulkCtx = document.createElement("textarea");
    bulkCtx.placeholder = "Contexto global (todas las páginas). Ej: Bernadi Cabanellas (Mallorca), jardinero…";
    bulkCtx.rows = 3;
    bulkCtx.style.cssText = "width:100%;padding:8px 10px;border:1px solid rgba(0,0,0,.2);border-radius:10px;resize:vertical;margin-bottom:8px;";

    const overwriteWrap = document.createElement("label");
    overwriteWrap.style.cssText = "display:flex;gap:8px;align-items:center;margin-bottom:10px;font-size:13px;";
    const overwrite = document.createElement("input");
    overwrite.type = "checkbox";
    overwrite.checked = true;
    const overwriteTxt = document.createElement("span");
    overwriteTxt.textContent = "Sobrescribir existentes";
    overwriteWrap.appendChild(overwrite);
    overwriteWrap.appendChild(overwriteTxt);

    const btnBulk = document.createElement("button");
    btnBulk.type = "button";
    btnBulk.textContent = "Generar SEO (TODAS las páginas)";
    btnBulk.style.cssText = "width:100%;background:#1d2327;color:#fff;border:none;border-radius:10px;padding:10px 12px;cursor:pointer;font-weight:800;";

    const msg = document.createElement("div");
    msg.style.cssText = "margin-top:10px;padding:10px 12px;border-radius:10px;display:none;border:1px solid rgba(0,0,0,.1);line-height:1.35;";

    function show(text, kind) {
      msg.style.display = "block";
      msg.textContent = text;
      msg.style.borderLeft = "5px solid " + (kind === "ok" ? "#00a32a" : kind === "warn" ? "#dba617" : "#d63638");
    }

    async function postJson(url, payload) {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-WP-Nonce": nonce },
        body: JSON.stringify(payload),
      });
      let data = null;
      try {
        data = await res.json();
      } catch (e) {
        throw new Error("Respuesta no JSON (¿caché/403?).");
      }
      if (!res.ok) throw new Error(data?.error || "Error desconocido");
      return data;
    }

    btnSingle.addEventListener("click", async () => {
      const postId = getPostId();
      if (!postId) return show("No pude detectar el ID del documento.", "err");

      btnSingle.disabled = true;
      btnSingle.style.opacity = "0.7";
      show("Generando SEO para esta página…", "warn");

      try {
        await postJson(endpoint, { post_id: postId, keyword: kw.value || "", extra_context: extra.value || "" });
        show("Guardado en Yoast. Si no lo ves, recarga.", "ok");
      } catch (e) {
        show("Error: " + (e.message || e), "err");
      } finally {
        btnSingle.disabled = false;
        btnSingle.style.opacity = "1";
      }
    });

    btnBulk.addEventListener("click", async () => {
      if (!endpoint_bulk) return show("No se encontró endpoint_bulk. Reinstala/actualiza el plugin.", "err");

      const ok = window.confirm("¿Generar SEO para TODAS las páginas? Puede tardar un poco si hay muchas.");
      if (!ok) return;

      btnBulk.disabled = true;
      btnBulk.style.opacity = "0.7";
      show("Generando SEO para todas las páginas… (se hace en lotes)", "warn");

      try {
        const data = await postJson(endpoint_bulk, {
          bulk_keyword: bulkKeyword.value || "",
          global_context: bulkCtx.value || "",
          overwrite: !!overwrite.checked,
        });
        show(`Listo ✅ Páginas actualizadas: ${data.saved_count} (lotes: ${data.batches})`, "ok");
      } catch (e) {
        show("Error: " + (e.message || e), "err");
      } finally {
        btnBulk.disabled = false;
        btnBulk.style.opacity = "1";
      }
    });

    card.appendChild(title);
    card.appendChild(kw);
    card.appendChild(extra);
    card.appendChild(btnSingle);
    card.appendChild(sep);
    card.appendChild(bulkKeyword);
    card.appendChild(bulkCtx);
    card.appendChild(overwriteWrap);
    card.appendChild(btnBulk);
    card.appendChild(msg);
    wrap.appendChild(card);
    document.body.appendChild(wrap);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", createUI);
  else createUI();
})();