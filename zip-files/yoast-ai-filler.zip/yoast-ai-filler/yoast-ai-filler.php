<?php
/**
 * Plugin Name: Yoast AI Filler (Custom)
 * Description: Genera con IA el título SEO, meta description y focus keyphrase, y los guarda en Yoast SEO. Incluye panel en Gutenberg y widget flotante en Elementor. Añade keyword objetivo, contexto adicional y SEO masivo para todas las páginas.
 * Version: 0.5.0
 */

if (!defined('ABSPATH')) exit;

class Yoast_Ai_Filler {
  const OPT_API_KEY = 'yoast_ai_filler_openai_api_key';
  const OPT_MODEL   = 'yoast_ai_filler_openai_model';

  public function __construct() {
    add_action('admin_menu', [$this, 'admin_menu']);
    add_action('admin_init', [$this, 'register_settings']);

    add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
    add_action('elementor/editor/after_enqueue_scripts', [$this, 'enqueue_elementor_assets']);

    add_action('rest_api_init', [$this, 'register_rest']);
  }

  private function yoast_available() {
    return class_exists('WPSEO_Meta'); // Yoast SEO
  }

  public function admin_menu() {
    add_options_page(
      'Yoast AI Filler',
      'Yoast AI Filler',
      'manage_options',
      'yoast-ai-filler',
      [$this, 'settings_page']
    );
  }

  public function register_settings() {
    register_setting('yoast_ai_filler', self::OPT_API_KEY, [
      'type' => 'string',
      'sanitize_callback' => 'sanitize_text_field',
      'default' => '',
    ]);
    register_setting('yoast_ai_filler', self::OPT_MODEL, [
      'type' => 'string',
      'sanitize_callback' => 'sanitize_text_field',
      'default' => 'gpt-4o-mini',
    ]);
  }

  public function settings_page() {
    if (!current_user_can('manage_options')) return;
    ?>
    <div class="wrap">
      <h1>Yoast AI Filler</h1>

      <h2>Configuración</h2>
      <form method="post" action="options.php">
        <?php settings_fields('yoast_ai_filler'); ?>
        <table class="form-table" role="presentation">
          <tr>
            <th scope="row"><label for="<?php echo esc_attr(self::OPT_API_KEY); ?>">OpenAI API Key</label></th>
            <td>
              <input type="password"
                     id="<?php echo esc_attr(self::OPT_API_KEY); ?>"
                     name="<?php echo esc_attr(self::OPT_API_KEY); ?>"
                     value="<?php echo esc_attr(get_option(self::OPT_API_KEY, '')); ?>"
                     class="regular-text"
                     autocomplete="off" />
            </td>
          </tr>
          <tr>
            <th scope="row"><label for="<?php echo esc_attr(self::OPT_MODEL); ?>">Modelo</label></th>
            <td>
              <input type="text"
                     id="<?php echo esc_attr(self::OPT_MODEL); ?>"
                     name="<?php echo esc_attr(self::OPT_MODEL); ?>"
                     value="<?php echo esc_attr(get_option(self::OPT_MODEL, 'gpt-4o-mini')); ?>"
                     class="regular-text" />
              <p class="description">Por defecto: <code>gpt-4o-mini</code></p>
            </td>
          </tr>
        </table>
        <?php submit_button(); ?>
      </form>

      <hr />

      <h2>SEO masivo (todas las páginas)</h2>
      <p>Genera título SEO, meta description y focus keyphrase para <strong>todas</strong> tus páginas, procurando que cada una sea distinta (Inicio ≠ Contacto ≠ Servicios…).</p>

      <table class="form-table" role="presentation">
        <tr>
          <th scope="row">Frase clave objetivo (base)</th>
          <td>
            <input id="yoast-ai-bulk-keyword" class="regular-text" type="text"
              placeholder="Ej: jardinería Mallorca" />
            <p class="description">Se adapta por página (ej: <em>contacto jardinería Mallorca</em>, <em>servicios jardinería Mallorca</em>…).</p>
          </td>
        </tr>
        <tr>
          <th scope="row">Contexto global (opcional)</th>
          <td>
            <textarea id="yoast-ai-bulk-context" class="large-text" rows="4"
              placeholder="Ej: Web para Bernadi Cabanellas de Mallorca, jardinero. Servicios: mantenimiento, diseño, poda. Tono cercano. Diferencial: presupuesto en 24h."></textarea>
            <p class="description">Tip: si pones nombre + ciudad, el plugin fuerza a mencionarlo en páginas clave (Inicio/Servicios/Contacto).</p>
          </td>
        </tr>
        <tr>
          <th scope="row">Sobrescribir existentes</th>
          <td>
            <label>
              <input type="checkbox" id="yoast-ai-bulk-overwrite" checked />
              Sí, sobrescribir aunque ya haya título/description en Yoast.
            </label>
          </td>
        </tr>
        <tr>
          <th scope="row"></th>
          <td>
            <button class="button button-primary" id="yoast-ai-bulk-run">Generar SEO para todas las páginas</button>
            <p id="yoast-ai-bulk-status" style="margin-top:10px;"></p>
            <pre id="yoast-ai-bulk-log" style="margin-top:10px;max-height:260px;overflow:auto;background:#111;color:#eee;padding:12px;border-radius:8px;display:none;"></pre>
          </td>
        </tr>
      </table>
    </div>
    <?php
  }

  private function localize_data() {
    $single = rest_url('yoast-ai-filler/v1/generate');
    return [
      'nonce' => wp_create_nonce('wp_rest'),
      'endpoint' => $single,
      'endpoint_single' => $single,
      'endpoint_bulk' => rest_url('yoast-ai-filler/v1/bulk-generate'),
    ];
  }

  public function enqueue_admin_assets($hook) {
    // Gutenberg editor
    if (in_array($hook, ['post.php', 'post-new.php'], true)) {
      if (!$this->yoast_available()) return;

      wp_enqueue_script(
        'yoast-ai-filler-admin',
        plugins_url('assets/yoast-ai-filler-admin.js', __FILE__),
        ['wp-plugins','wp-edit-post','wp-element','wp-components','wp-data'],
        '0.5.0',
        true
      );
      wp_localize_script('yoast-ai-filler-admin', 'YoastAiFiller', $this->localize_data());
      return;
    }

    // Settings page
    if ($hook === 'settings_page_yoast-ai-filler') {
      if (!$this->yoast_available()) return;

      wp_enqueue_script(
        'yoast-ai-filler-bulk',
        plugins_url('assets/yoast-ai-filler-bulk.js', __FILE__),
        [],
        '0.5.0',
        true
      );
      wp_localize_script('yoast-ai-filler-bulk', 'YoastAiFiller', $this->localize_data());
    }
  }

  public function enqueue_elementor_assets() {
    if (!$this->yoast_available()) return;

    wp_enqueue_script(
      'yoast-ai-filler-elementor',
      plugins_url('assets/yoast-ai-filler-elementor.js', __FILE__),
      [],
      '0.5.0',
      true
    );

    wp_localize_script('yoast-ai-filler-elementor', 'YoastAiFiller', $this->localize_data());
  }

  public function register_rest() {
    // Single
    register_rest_route('yoast-ai-filler/v1', '/generate', [
      'methods' => 'POST',
      'permission_callback' => function($request) {
        $post_id = (int) $request->get_param('post_id');
        return $post_id > 0 && current_user_can('edit_post', $post_id);
      },
      'callback' => [$this, 'rest_generate'],
      'args' => [
        'post_id' => ['required' => true],
        'keyword' => ['required' => false],
        'extra_context' => ['required' => false],
      ]
    ]);

    // Bulk
    register_rest_route('yoast-ai-filler/v1', '/bulk-generate', [
      'methods' => 'POST',
      'permission_callback' => function() {
        return current_user_can('manage_options');
      },
      'callback' => [$this, 'rest_bulk_generate'],
      'args' => [
        'bulk_keyword' => ['required' => false],
        'global_context' => ['required' => false],
        'overwrite' => ['required' => false],
      ]
    ]);
  }

  private function clip($s, $max_chars) {
    $s = trim((string)$s);
    if (function_exists('mb_strlen') && function_exists('mb_substr')) {
      return (mb_strlen($s) > $max_chars) ? mb_substr($s, 0, $max_chars) : $s;
    }
    return (strlen($s) > $max_chars) ? substr($s, 0, $max_chars) : $s;
  }

  private function guess_page_role($title, $slug) {
    $t = function_exists('mb_strtolower') ? mb_strtolower($title . ' ' . $slug) : strtolower($title . ' ' . $slug);
    $map = [
      'home' => ['inicio','home','principal','portada'],
      'contact' => ['contacto','contact','contáct','formular','llámanos'],
      'services' => ['servicios','service','tratamientos','soluciones','precios'],
      'about' => ['sobre','acerca','quienes','quiénes','nosotros','historia'],
      'team' => ['equipo','team','staff','profesionales'],
      'blog' => ['blog','artículos','noticias','novedades'],
      'legal' => ['aviso legal','privacidad','cookies','legal','condiciones','términos'],
    ];
    foreach ($map as $role => $words) {
      foreach ($words as $w) {
        if (function_exists('mb_strpos')) {
          if (mb_strpos($t, $w) !== false) return $role;
        } else {
          if (strpos($t, $w) !== false) return $role;
        }
      }
    }
    return 'generic';
  }

  private function ensure_desc_length($desc, $site_name, $fallback_bits = '') {
    $desc = trim((string)$desc);

    // Si es demasiado corta, intentamos alargarla de forma natural (sin inventar).
    if (function_exists('mb_strlen')) {
      $len = mb_strlen($desc);
    } else {
      $len = strlen($desc);
    }

    if ($len < 140) {
      $append = '';
      if (!empty($fallback_bits)) $append = ' ' . trim($fallback_bits);
      else $append = ' ' . $site_name;

      $desc = trim($desc . $append);
    }

    // Clip a 155
    $desc = $this->clip($desc, 155);

    // Si sigue por debajo de ~135 por clipping raro, no hacemos más.
    return $desc;
  }

  private function openai_call($api_key, $payload) {
    $response = wp_remote_post('https://api.openai.com/v1/responses', [
      'timeout' => 85,
      'headers' => [
        'Authorization' => 'Bearer ' . $api_key,
        'Content-Type'  => 'application/json',
      ],
      'body' => wp_json_encode($payload),
    ]);

    if (is_wp_error($response)) {
      return ['error' => true, 'message' => $response->get_error_message()];
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);

    if ($code < 200 || $code >= 300) {
      return ['error' => true, 'status' => $code, 'raw' => $body];
    }

    $data = json_decode($body, true);

    $text = '';
    if (!empty($data['output'])) {
      foreach ($data['output'] as $out) {
        if (!empty($out['content'])) {
          foreach ($out['content'] as $c) {
            if (($c['type'] ?? '') === 'output_text') {
              $text .= $c['text'] ?? '';
            }
          }
        }
      }
    }

    $json = json_decode(trim($text), true);
    if (!is_array($json)) {
      return ['error' => true, 'message' => 'JSON inválido', 'raw_text' => $text];
    }

    return ['error' => false, 'json' => $json];
  }

  // ---------- SINGLE ----------
  public function rest_generate(WP_REST_Request $request) {
    if (!$this->yoast_available()) return new WP_REST_Response(['error' => 'Yoast SEO no está activo.'], 400);

    $api_key = get_option(self::OPT_API_KEY, '');
    if (empty($api_key)) return new WP_REST_Response(['error' => 'Falta OpenAI API Key en Ajustes > Yoast AI Filler.'], 400);

    $model = get_option(self::OPT_MODEL, 'gpt-4o-mini') ?: 'gpt-4o-mini';

    $post_id = (int) $request->get_param('post_id');
    $post = get_post($post_id);
    if (!$post) return new WP_REST_Response(['error' => 'Post no encontrado.'], 404);

    $keyword = sanitize_text_field((string) $request->get_param('keyword'));
    $extra_context = sanitize_textarea_field((string) $request->get_param('extra_context'));

    $title   = wp_strip_all_tags(get_the_title($post_id));
    $excerpt = wp_strip_all_tags(get_the_excerpt($post_id));
    $content = $this->clip(wp_strip_all_tags($post->post_content), 8000);

    $site_name = wp_strip_all_tags(get_bloginfo('name'));
    $lang = get_bloginfo('language');

    $system = "Eres un especialista SEO senior. Devuelve SOLO JSON válido del esquema. Prioriza precisión: no inventes servicios, ubicaciones o claims.";

    $kw_line = !empty($keyword) ? "Palabra clave objetivo (úsala tal cual): {$keyword}\n" : "Palabra clave objetivo: (no proporcionada)\n";
    $extra_line = !empty($extra_context) ? "Contexto adicional del editor (USAR TAL CUAL si hay nombre/ciudad):\n{$extra_context}\n\n" : "";

    $user =
"Idioma del sitio: {$lang}
Marca/website: {$site_name}

{$kw_line}
OBJETIVO: maximizar relevancia y CTR, y ayudar a conseguir 'caritas verdes' en Yoast, SIN inventar datos.

REGLAS (muy importantes):
- focus_keyphrase: si el editor dio keyword, DEVUELVE EXACTAMENTE ESA keyword.
- Incluye la focus_keyphrase en el seo_title y en la meta_description de forma natural.
- seo_title: 50–60 caracteres, con intención clara.
- meta_description: 145–155 caracteres (evita que quede corta). Incluye beneficio + CTA suave.
- Si el contexto incluye un nombre (persona/negocio) o ciudad, intenta incluir uno de ellos en título o descripción sin spamear.
- No inventes: si no aparece en contenido/contexto, no lo menciones.

PROCESO (interno):
- Genera 5 opciones de título + 5 descripciones.
- Elige la mejor por: relevancia + CTR + longitudes + coherencia con el contenido.
- Devuelve solo la elegida.

{$extra_line}DATOS:
- Título: {$title}
- Extracto: {$excerpt}
- Contenido: {$content}
";

    $schema = [
      "type" => "object",
      "properties" => [
        "seo_title" => ["type" => "string"],
        "meta_description" => ["type" => "string"],
        "focus_keyphrase" => ["type" => "string"],
      ],
      "required" => ["seo_title","meta_description","focus_keyphrase"],
      "additionalProperties" => false
    ];

    $payload = [
      "model" => $model,
      "input" => [
        ["role" => "system", "content" => $system],
        ["role" => "user", "content" => $user],
      ],
      "text" => [
        "format" => [
          "type" => "json_schema",
          "name" => "yoast_meta",
          "schema" => $schema,
          "strict" => true
        ]
      ]
    ];

    $result = $this->openai_call($api_key, $payload);
    if ($result['error']) return new WP_REST_Response($result, 500);

    $json = $result['json'];

    $seo_title = sanitize_text_field($json['seo_title'] ?? '');
    $metadesc  = sanitize_text_field($json['meta_description'] ?? '');
    $focuskw   = sanitize_text_field($json['focus_keyphrase'] ?? '');

    if (!empty($keyword)) $focuskw = $keyword;

    $seo_title = $this->clip($seo_title, 60);
    $metadesc  = $this->ensure_desc_length($this->clip($metadesc, 155), $site_name);
    $focuskw   = $this->clip($focuskw, 120);

    if ($seo_title) WPSEO_Meta::set_value('title', $seo_title, $post_id);
    if ($metadesc)  WPSEO_Meta::set_value('metadesc', $metadesc, $post_id);
    if ($focuskw)   WPSEO_Meta::set_value('focuskw', $focuskw, $post_id);

    return new WP_REST_Response([
      'ok' => true,
      'post_id' => $post_id,
      'saved' => [
        'seo_title' => $seo_title,
        'meta_description' => $metadesc,
        'focus_keyphrase' => $focuskw,
      ],
    ], 200);
  }

  // ---------- BULK ----------
  public function rest_bulk_generate(WP_REST_Request $request) {
    if (!$this->yoast_available()) return new WP_REST_Response(['error' => 'Yoast SEO no está activo.'], 400);

    $api_key = get_option(self::OPT_API_KEY, '');
    if (empty($api_key)) return new WP_REST_Response(['error' => 'Falta OpenAI API Key en Ajustes > Yoast AI Filler.'], 400);

    $model = get_option(self::OPT_MODEL, 'gpt-4o-mini') ?: 'gpt-4o-mini';

    $bulk_keyword = sanitize_text_field((string) $request->get_param('bulk_keyword'));
    $global_context = sanitize_textarea_field((string) $request->get_param('global_context'));
    $overwrite = (bool) $request->get_param('overwrite');

    $site_name = wp_strip_all_tags(get_bloginfo('name'));
    $lang = get_bloginfo('language');

    $pages = get_posts([
      'post_type' => 'page',
      'post_status' => 'publish',
      'numberposts' => -1,
      'orderby' => 'menu_order',
      'order' => 'ASC',
    ]);

    if (empty($pages)) return new WP_REST_Response(['ok'=>true,'saved'=>[],'note'=>'No hay páginas publicadas.'], 200);

    $items = [];
    foreach ($pages as $p) {
      $pid = $p->ID;

      $existing_title = get_post_meta($pid, '_yoast_wpseo_title', true);
      $existing_desc  = get_post_meta($pid, '_yoast_wpseo_metadesc', true);
      $existing_kw    = get_post_meta($pid, '_yoast_wpseo_focuskw', true);

      if (!$overwrite && (!empty($existing_title) && !empty($existing_desc) && !empty($existing_kw))) {
        continue;
      }

      $title = wp_strip_all_tags(get_the_title($pid));
      $slug  = $p->post_name;
      $role  = $this->guess_page_role($title, $slug);
      $content = $this->clip(wp_strip_all_tags($p->post_content), 1500);

      $items[] = [
        'post_id' => $pid,
        'title' => $title,
        'slug' => $slug,
        'role_guess' => $role,
        'content_hint' => $content,
      ];
    }

    if (empty($items)) {
      return new WP_REST_Response(['ok'=>true,'saved'=>[],'note'=>'Nada que generar (o ya estaban completos y no se permite sobrescribir).'], 200);
    }

    // Lotes para evitar límites de tokens.
    $batches = $this->split_into_batches($items, 14);

    $saved_all = [];
    $log = [];

    foreach ($batches as $bi => $batch) {
      $system = "Eres un especialista SEO senior. Devuelve SOLO JSON válido del esquema. No repitas títulos ni descripciones entre páginas. No inventes información.";
      $ctx = !empty($global_context) ? "Contexto global (USAR TAL CUAL, especialmente nombre y ciudad si aparecen):\n{$global_context}\n\n" : "";
      $kw = !empty($bulk_keyword) ? "Frase clave base (USAR como base y adaptar por página): {$bulk_keyword}\n\n" : "Frase clave base: (no proporcionada)\n\n";

      $user = "Idioma del sitio: {$lang}\nMarca/website: {$site_name}\n\n"
        . $kw
        . $ctx
        . "OBJETIVO: maximizar relevancia y CTR y ayudar a conseguir 'caritas verdes' en Yoast para CADA página.\n"
        . "REGLAS DE CALIDAD (IMPORTANTES):\n"
        . "- Para cada página devuelve focus_keyphrase. Si hay frase clave base, CREA una variante por tipo de página (sin repetir exacto):\n"
        . "  * home: '{base}'\n"
        . "  * contact: 'contacto {base}'\n"
        . "  * services: 'servicios {base}' o '{base} servicios'\n"
        . "  * about/team/legal/blog: variante coherente (ej: 'equipo {base}', 'aviso legal {base}').\n"
        . "- Incluye la focus_keyphrase en el seo_title y en la meta_description de forma natural.\n"
        . "- seo_title: 50–60 caracteres.\n"
        . "- meta_description: 145–155 caracteres (NO corta). Beneficio + CTA suave.\n"
        . "- No uses textos genéricos: debe encajar con content_hint y con el title/slug.\n"
        . "- Si el contexto trae nombre y ciudad, menciona al menos UNO en páginas clave (home/services/contact) sin spamear.\n"
        . "- Evita repetir títulos/descripciones entre páginas.\n\n"
        . "PÁGINAS (JSON):\n" . wp_json_encode($batch);

      $schema = [
        "type" => "object",
        "properties" => [
          "pages" => [
            "type" => "array",
            "items" => [
              "type" => "object",
              "properties" => [
                "post_id" => ["type" => "integer"],
                "seo_title" => ["type" => "string"],
                "meta_description" => ["type" => "string"],
                "focus_keyphrase" => ["type" => "string"],
              ],
              "required" => ["post_id","seo_title","meta_description","focus_keyphrase"],
              "additionalProperties" => false
            ]
          ]
        ],
        "required" => ["pages"],
        "additionalProperties" => false
      ];

      $payload = [
        "model" => $model,
        "input" => [
          ["role" => "system", "content" => $system],
          ["role" => "user", "content" => $user],
        ],
        "text" => [
          "format" => [
            "type" => "json_schema",
            "name" => "yoast_bulk",
            "schema" => $schema,
            "strict" => true
          ]
        ]
      ];

      $result = $this->openai_call($api_key, $payload);
      if ($result['error']) {
        return new WP_REST_Response([
          'error' => 'Error en OpenAI (bulk)',
          'detail' => $result,
          'batch_index' => $bi
        ], 500);
      }

      $out = $result['json'];
      $pages_out = $out['pages'] ?? [];
      if (!is_array($pages_out)) $pages_out = [];

      // Dedupe a nivel de batch
      $seen_titles = [];
      $seen_descs  = [];

      foreach ($pages_out as $row) {
        $pid = (int) ($row['post_id'] ?? 0);
        if ($pid <= 0) continue;

        $seo_title = $this->clip(sanitize_text_field($row['seo_title'] ?? ''), 60);
        $metadesc  = $this->clip(sanitize_text_field($row['meta_description'] ?? ''), 155);
        $focuskw   = $this->clip(sanitize_text_field($row['focus_keyphrase'] ?? ''), 120);

        // Si se dio frase base, garantizamos que no esté vacía y que sea variante.
        if (!empty($bulk_keyword) && empty($focuskw)) {
          $focuskw = $bulk_keyword;
        }

        // Alargar meta si queda corta
        $metadesc = $this->ensure_desc_length($metadesc, $site_name, $bulk_keyword ? ("Más info sobre " . $bulk_keyword . ".") : "");

        if (isset($seen_titles[$seo_title])) $seo_title = $this->clip($seo_title . ' | ' . $site_name, 60);
        if (isset($seen_descs[$metadesc]))  $metadesc  = $this->ensure_desc_length($this->clip($metadesc . ' ' . $site_name, 155), $site_name);

        $seen_titles[$seo_title] = true;
        $seen_descs[$metadesc] = true;

        if ($seo_title) WPSEO_Meta::set_value('title', $seo_title, $pid);
        if ($metadesc)  WPSEO_Meta::set_value('metadesc', $metadesc, $pid);
        if ($focuskw)   WPSEO_Meta::set_value('focuskw', $focuskw, $pid);

        $saved_all[] = [
          'post_id' => $pid,
          'seo_title' => $seo_title,
          'meta_description' => $metadesc,
          'focus_keyphrase' => $focuskw
        ];
      }

      $log[] = "Lote " . ($bi+1) . "/" . count($batches) . ": actualizado " . count($pages_out) . " páginas.";
    }

    return new WP_REST_Response([
      'ok' => true,
      'saved_count' => count($saved_all),
      'saved' => $saved_all,
      'batches' => count($batches),
      'log' => $log,
      'note' => $overwrite ? 'Sobrescribiendo activado.' : 'No sobrescribe si ya existía SEO completo.'
    ], 200);
  }

  private function split_into_batches($items, $batch_size) {
    $out = [];
    $chunk = [];
    foreach ($items as $it) {
      $chunk[] = $it;
      if (count($chunk) >= $batch_size) {
        $out[] = $chunk;
        $chunk = [];
      }
    }
    if (!empty($chunk)) $out[] = $chunk;
    return $out;
  }
}

new Yoast_Ai_Filler();
